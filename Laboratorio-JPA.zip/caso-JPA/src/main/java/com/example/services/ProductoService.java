/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;
import com.example.PersistenceManager;
import com.example.models.Producto;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author USUARIO
 */
@Path("/producto")
@Produces(MediaType.APPLICATION_JSON)
public class ProductoService {
    
    //Atributo EntityManager: Corresponde clase java Producto
    @PersistenceContext(unitName = "org.example_Laboratorio-JPA_jar_persistencia")
    EntityManager entityManagerProduto;
    
    //Inicializacion: Corresponde clase java Producto
     @PostConstruct
    public void initProducto() {
        try {
            entityManagerProduto = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
     //Get: De la clase java Producto 
    
    @GET
    @Path("/getProducto")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProducto() {
        Query q = entityManagerProduto.createQuery("select u from Producto u order by u.surname ASC");
        List<Producto> productos = q.getResultList();
        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(productos).build();
    }
    
    
    //Post: De la clase java Producto 
    @POST
    @Path("/addProducto")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createProducto(Producto producto) {
        JSONObject rta = new JSONObject();
        Producto productoTmp = new Producto();
        //productoTmp.setId(producto.getId());
        productoTmp.setName(producto.getName());
        productoTmp.setPrice(producto.getPrice());
        productoTmp.setDescrption(producto.getDescription());
        try {
            entityManagerProduto.getTransaction().begin();
            entityManagerProduto.persist(productoTmp);
            entityManagerProduto.getTransaction().commit();
            entityManagerProduto.refresh(productoTmp);
            rta.put("Producto_id", productoTmp.getId());
        } catch (Throwable t) {
            t.printStackTrace();
            if (entityManagerProduto.getTransaction().isActive()) {
                entityManagerProduto.getTransaction().rollback();
            }
            productoTmp = null;
        } finally {
            entityManagerProduto.clear();
            entityManagerProduto.close();
        }
        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(rta).build();
    }
    
}
