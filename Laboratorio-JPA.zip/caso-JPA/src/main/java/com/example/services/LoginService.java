/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;

import com.example.PersistenceManager;
import com.example.models.Competitor;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

@Path("/login")
@Produces(MediaType.APPLICATION_JSON)
public class LoginService {

    @PersistenceContext(unitName = "org.example_Laboratorio-JPA_jar_persistencia")
    private EntityManager entityManager;
    
      @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @GET
    @Path("/{address}/{contraseña}")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response login(@PathParam("address") String address, @PathParam("contraseña") String contraseña) {
        try {
            Query q = entityManager.createQuery("SELECT c FROM Competitor c WHERE c.address = :address AND c.contraseña = :contraseña");
            q.setParameter("address", address);
            q.setParameter("contraseña", contraseña);

            Competitor competitor = (Competitor) q.getSingleResult();

            if (competitor.getContraseña().equals(contraseña)&& competitor.getAddress().equals(address)) {
                return Response.ok(competitor).build();
            } else {
                return Response.status(Response.Status.UNAUTHORIZED)
                        .entity("{\"error\": \"Credenciales inválidas\"}")
                        .header("Access-Control-Allow-Origin", "*")
                        .build();

            }
        } catch (NoResultException e) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .entity("{\"error\": \"Credenciales inválidas\"}")
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        }
    }
}
