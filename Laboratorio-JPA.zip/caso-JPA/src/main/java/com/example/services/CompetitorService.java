/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Creación del Entity Manager, modificaciones sobre la clase en donde estamos exponiendo los servicios REST
//Entity Manager: El cual es la interfaz que nos permite hacer persistentes nuestras Entities
//Entity Manager:permite realizar distintas consultas o queries.
// Entity Manager: El ciclo de vida es manejado por el contenedor de aplicaciones.
package com.example.services;

import com.example.PersistenceManager;
import com.example.models.Competitor;
import com.example.models.CompetitorDTO;
import com.example.models.Producto;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author Mauricio
 */
@Path("/competitors")
@Produces(MediaType.APPLICATION_JSON)
public class CompetitorService {

    
    
    /*crear un atributo de tipo EntityManager con la anotación @PersistenceContext() 
      para indicarle cuál es el contexto que usaremos
     */
    @PersistenceContext(unitName = "org.example_Laboratorio-JPA_jar_persistencia")
    EntityManager entityManager;

    
    
    /*inicialización del EntityManager
    Esta inicialización la haremos con un método que se ejecutará antes de que se acceda a los servicios,
    para esto usaremos la anotación @PostConstruct.
     */
    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
   

    /*consultar todos los concursantes del sorteo.
    Query: nos comunicaremos con la base de datos para realizar la consulta usando JPQL.
     */
    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        Query q = entityManager.createQuery("select u from Competitor u order by u.surname ASC");
        List<Competitor> competitors = q.getResultList();
        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(competitors).build();
    }
    
   

    
    
    /*Creacion del servico de insercion
    Para hacer persistente un objeto en la base de datos:
    I. crear una transacción a través del Entity Manager. 
    II. Debemos indicarle el objeto que queremos hacer persistente. 
    III. Finalmente hacemos commit sobre la transacción
    */
    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCompetitor(CompetitorDTO competitor) {
        JSONObject rta = new JSONObject();
        Competitor competitorTmp = new Competitor();
        competitorTmp.setAddress(competitor.getAddress());
        competitorTmp.setAge(competitor.getAge());
        competitorTmp.setCellphone(competitor.getCellphone());
        competitorTmp.setCity(competitor.getCity());
        competitorTmp.setCountry(competitor.getCountry());
        competitorTmp.setName(competitor.getName());
        competitorTmp.setSurname(competitor.getSurname());
        competitorTmp.setTelephone(competitor.getTelephone());
        competitorTmp.setContraseña(competitor.getContraseña());
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(competitorTmp);
            entityManager.getTransaction().commit();
            entityManager.refresh(competitorTmp);
            rta.put("competitor_id", competitorTmp.getId());
        } catch (Throwable t) {
            t.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            competitorTmp = null;
        } finally {
            entityManager.clear();
            entityManager.close();
        }
        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(rta).build();
    }
    
    

}
